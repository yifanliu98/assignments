Functions and main function for testing are separated into different .jl files
To see the output of the function, compile and run every file using the command as the shown in the following

julia ./divisors_primes.jl
julia ./join.jl
julia ./pythagorean.jl
julia ./hailSeq.jl
julia ./mergeSort.jl
julia ./fib.jl
