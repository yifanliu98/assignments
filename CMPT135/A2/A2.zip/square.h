#ifndef SQUARE_H
#define SQUARE_H
#include "rectangle.h"

class Square : public Rectangle
{
public:
	Square();
	Square(Point, double);

	double getSideLength() const;
	void setSideLength(double);
	virtual void display() const;
	virtual void setLength(double);
	virtual void setWidth(double);
};

#endif