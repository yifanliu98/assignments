#include <iostream>
#include "point.h"
using namespace std;

Point::Point() : X(0), Y(0){}
Point::Point(double x, double y) : X(x), Y (y){}

void Point::setX(double x)
{
	X = x;
}

void Point::setY(double y)
{
	Y = y;
}

double Point::getX() const
{
	return X;
}

double Point::getY() const 
{
	return Y;
}

ostream& operator<< (ostream& dataRiver, const Point& p)
{
	dataRiver << "(" << p.getX() << ", " << p.getY() << ")";
	return dataRiver;
}
