#ifndef POINT_H
#define POINT_H
#include <iostream>
using namespace std;

class Point
{
public:
	Point(); 
	Point(double, double); 

	void setX(double); 
	void setY(double); 
	double getX() const;
	double getY() const;
	friend ostream& operator<< (ostream&, const Point&);

private:
	double X;
	double Y;
};

#endif