#ifndef CIRCLE_H
#define CIRCLE_H
#include "shape.h"
#include "math.h"
#define _USE_MATH_DEFINES

class Circle : public Shape
{
public:
	Circle();
	Circle(Point,double);

	double getRadius() const;
	void setRadius(double);
	virtual double area();
	virtual double perimeter();
	virtual void display() const;

private:
	double radius;
};

#endif