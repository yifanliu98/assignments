#include <iostream>
#include "circle.h"
#include "math.h"
#define _USE_MATH_DEFINES
using namespace std;

Circle::Circle() : Shape(), radius(0){}
Circle::Circle(Point centre_point, double circle_radius) : Shape(centre_point), radius(circle_radius){}

double Circle::getRadius() const
{
	return radius;
}

void Circle::setRadius(double rad)
{
	radius = rad;
}

double Circle::area()
{
	return pow(radius,2) * M_PI;
}

double Circle::perimeter()
{
	return 2 * M_PI * radius;
}

void Circle::display() const
{
	cout << "\nCircle:\n\tCentre: " << centre << endl
		 << "\tRadius: " << radius << endl << endl;
}
