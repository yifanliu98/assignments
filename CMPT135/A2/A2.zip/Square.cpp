#include <iostream>
#include "square.h"
using namespace std;

Square::Square() : Rectangle(){}
Square::Square(Point centre_point, double side_len) : Rectangle(centre_point, side_len, side_len){}
void Square::display() const
{
	cout << "\nSquare:\n\tCentre: " << centre << endl
		 << "\tSide Length: " << length << endl << endl;
}

void Square::setLength (double len)
{
	length = len;
	width = len;
}

void Square::setWidth (double wid)
{
	setLength(wid);
}

void Square::setSideLength (double sideLen)
{
	setLength(sideLen);
}

double Square::getSideLength() const
{
	return length;
}