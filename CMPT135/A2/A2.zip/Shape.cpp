#include <iostream>
#include "point.h"
#include "shape.h"
using namespace std;

Shape::Shape() : centre(Point()){}
Shape::Shape(Point cen) : centre(cen){}

Point Shape::getCentre() const
{
	return centre;
}

void Shape::setCentre(Point centre_point)
{
	centre = centre_point;
}

void Shape::display() const
{
	cout << "\nShape:\n\tCentre: " << centre << endl << endl;
}

void Shape::reflectX()
{
	centre.setY(centre.getY() * -1);
}

void Shape::reflectY()
{
	centre.setX(centre.getX() * -1);
}

void Shape::translate(double x, double y)
{
	centre.setX(centre.getX() + x); 
	centre.setY(centre.getY() + y); 
}