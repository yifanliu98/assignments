#ifndef RECTANGLE_H
#define RECTANGLE_H
#include "shape.h"

class Rectangle : public Shape
{
public:
	Rectangle();
	Rectangle(Point, double, double);

	double getLength() const;
	double getWidth() const;
	virtual void setLength(double);
	virtual void setWidth(double);
	virtual double area();
	virtual double perimeter();
	virtual void display() const;
	void printFourVertices() const;
	
protected:
	double length;
	double width;
};

#endif