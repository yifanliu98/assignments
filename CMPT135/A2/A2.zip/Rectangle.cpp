#include <iostream>
#include "rectangle.h"
using namespace std;

Rectangle::Rectangle() : Shape(), length(0), width(0){}
Rectangle::Rectangle(Point centre_point, double len, double wid) : Shape(centre_point), length(len), width(wid){}

double Rectangle::getLength() const
{
	return length;
}

double Rectangle::getWidth() const
{
	return width;
}

void Rectangle::setLength(double len)
{
	length = len;
}

void Rectangle::setWidth(double wid)
{
	width = wid;
}

double Rectangle::area()
{
	return length * width;
}

double Rectangle::perimeter()
{
	return (length + width) * 2;
}

void Rectangle::display() const
{
	cout << "\nRectangle:\n\tCentre: " << centre << endl
		 << "\tLength: " << length << endl
		 << "\tWidth: " << width << endl << endl;
}

void Rectangle::printFourVertices() const
{
	double x_right, x_left, y_top, y_bottom;
	x_right = centre.getX() + length / 2.0;
	x_left = x_right - length;
	y_top = centre.getY() + width / 2.0;
	y_bottom = y_top - width;

	Point p1(x_left, y_top), p2(x_right, y_top), p3(x_right, y_bottom), p4(x_left, y_bottom);
	cout << p1 << endl << p2 << endl << p3 << endl << p4 <<endl;
}