#include <iostream>
#include "string.h"
using namespace std;

void reverse_recursive (char* arr, int start, int end)
{
	if (start >= end)
		return;
	else 
	{
		char temp = arr[start];
		arr[start] = arr[end];
		arr[end] = temp;
		reverse_recursive(arr, start+1, end-1);
	}
}

void reverse (char* str)
{
	if(str == NULL)
		return;
	reverse_recursive(str,0,strlen(str)-1);
}
