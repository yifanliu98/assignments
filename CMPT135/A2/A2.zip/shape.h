#ifndef SHAPE_H
#define SHAPE_H
#include "point.h"

class Shape
{
public:
	Shape();
	Shape(Point);

	Point getCentre() const;
	void setCentre(Point);
	virtual double area() = 0;
	virtual double perimeter() = 0;
	virtual void display() const;
	void reflectX();
	void reflectY();
	void translate (double, double);

protected:
	Point centre;
};

#endif